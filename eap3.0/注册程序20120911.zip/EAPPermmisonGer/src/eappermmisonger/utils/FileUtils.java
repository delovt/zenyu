/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package eappermmisonger.utils;

import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import javax.swing.filechooser.FileSystemView;

/**
 *
 * @author Administrator
 */
public class FileUtils {
        
    
    	public static void newFile(String filePathAndName, String fileContent) { 
		try { 
		            String filePath = filePathAndName; 
		            filePath = filePath.toString(); 
		            File myFilePath = new File(filePath); 
		            if (!myFilePath.exists()) { 
		                myFilePath.createNewFile(); 
		            } 
		            FileWriter resultFile = new FileWriter(myFilePath); 
		            PrintWriter myFile = new PrintWriter(resultFile); 
		            String strContent = fileContent; 
		            myFile.println(strContent); 
		            resultFile.close(); 
		        } catch (Exception e) { 
		            System.out.println("新建文件操作出错 "); 
		            e.printStackTrace(); 
		        } 
		    }
        
        public  static String makeContent(String fileContent){  
	       //v.getHomeDirectory(); //这便是读取桌面路径的方法了 
               String content="Product.signature=";
                FileSystemView fsv = FileSystemView.getFileSystemView();
	        System.out.println("桌面路径"+fsv.getHomeDirectory().getAbsolutePath());
                String strpath=fsv.getHomeDirectory().getAbsolutePath() + "\\license.properties";
                content=content+fileContent;
	    try {
		   FileUtils.newFile(strpath, content);
                   //this.getMainJFrame().
                   return "suc";
	   } catch (Exception e) { 
		   e.printStackTrace();
                   return "fail";
	    }
     
        }
        
    
}

