package core;

import java.util.Map;
import java.util.HashMap;
import java.util.Properties;

/**
 *
 * @author ndq
 */
public class Constant {
    /****
     * 装载配置文件里
     */
    public static Map<String, String> values = new HashMap<String, String>();

    /****
     * 文件目录路径
     */
    public static String filePath ;

    /****
     * 文件流属性
     */
    public static Properties properties = new Properties();
    
    /***
     * @param
     */
    public static void main(String[] args) {
	}
}
