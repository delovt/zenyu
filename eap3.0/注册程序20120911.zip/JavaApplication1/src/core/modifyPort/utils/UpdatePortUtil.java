package core.modifyPort.utils;

import java.io.FileOutputStream;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;


public class UpdatePortUtil {

    public static String updatePort(String filepath,String inputPort) {
        try {
            // 1.得到DOM解析器的工厂实例
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            // 2.从DOM工厂里获取DOM解析器
            DocumentBuilder db = dbf.newDocumentBuilder();
            // 3.解析XML文档，得到document，即DOM树
            Document doc = db.parse(filepath);
            
            NodeList list=doc.getElementsByTagName("Connector");
            for(int i=0;i<list.getLength();i++){
                Element brandElement=(Element) list.item(i);
                String protocol=brandElement.getAttribute("protocol");
                if(protocol.equals("HTTP/1.1")){
                    //属性修改
                    brandElement.setAttribute("port", inputPort);
                }
            }
            
            
            //保存xml文件
            TransformerFactory transformerFactory=TransformerFactory.newInstance();
            Transformer transformer=transformerFactory.newTransformer();
            DOMSource domSource=new DOMSource(doc);
            //设置编码类型
            transformer.setOutputProperty(OutputKeys.ENCODING, "GB2312");
            StreamResult result=new StreamResult(new FileOutputStream(filepath));
            //把DOM树转换为xml文件
            transformer.transform(domSource, result);
            return "suc";
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            return "fail";
        }
    } 
//    public static void main(String[] args) {
//    	    updateSerPort.updatePort("server.xml");
//	}
}
