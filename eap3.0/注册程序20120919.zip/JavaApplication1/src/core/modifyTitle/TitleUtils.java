/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package core.modifyTitle;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Administrator
 */
public class TitleUtils {
    

	private static String tempString=null;
	/**
	 * 修改系统标题
	 * @param fName
	 * @return
	 * @throws Exception
	 */
       public static boolean changeFile(String fName,String title) throws Exception{   
         //创建一个随机读写文件对象   
    	 RandomAccessFile raf1=new RandomAccessFile(fName,"rw");
         try {
			//System.out.println("-----------------"+tempString);
			StringBuffer buff = new StringBuffer();
			int r = 0;
			byte[] b = new byte[1024 * 10];
			while ((r = raf1.read(b, 0, 1024 * 10)) > -1) {
			    buff.append(new String(b, 0, r, "UTF-8"));
			}
			raf1.seek(0);
			raf1.setLength(0);
			raf1.write(buff.toString().replace(tempString, "           <title>"+title+"</title>").getBytes());
		} catch (Exception e) {
			raf1.close();
			e.printStackTrace();
		}
        return true;    
    } 
     //获取之前的项目的标题
    public static void getStr(String fName){

    	RandomAccessFile raf=null;
		try {
			raf = new RandomAccessFile(fName,"rw");
			try {
		    	int line=1;
				while((tempString = raf.readLine())!= null){
				// 显示行号
				if(tempString.trim().startsWith("<title>")&&tempString.trim().endsWith("</title>")){
					tempString = new String(tempString.getBytes("8859_1"), "UTF-8");//转变编码格式
					System.out.println("line: "+line+" "+tempString);
					break;
				}
				line++;
                }
				raf.close();
			} catch (IOException e) {
				try {
					raf.close();
				} catch (IOException e1) {
					e1.printStackTrace();
				}
				e.printStackTrace();
			}
		} catch (FileNotFoundException e) {
			try {
				raf.close();
			} catch (IOException e1) {
				e1.printStackTrace();
			}
			e.printStackTrace();
		}  
    }
    //测试主方法   
    public static void main(String[] args) throws Exception{ 
    	String title="元申软件";
    	TitleUtils.getStr("index.jsp");
    	TitleUtils.changeFile("index.jsp",title);   
    }  
    public static void updateTitle(String filePath,String title){
        try {
            TitleUtils.getStr(filePath);
            TitleUtils.changeFile(filePath,title);
        } catch (Exception ex) {
            Logger.getLogger(TitleUtils.class.getName()).log(Level.SEVERE, null, ex);
        }        
    }

}
