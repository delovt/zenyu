/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package core.generateRegister.Utils;

import core.MainJFrame;
import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import javax.swing.filechooser.FileSystemView;

/**
 *
 * @author Administrator
 */
public class FileUtils {
        
    
    	public static void newFile(String filePathAndName, String fileContent) { 
		try { 
		            String filePath = filePathAndName; 
		            filePath = filePath.toString(); 
		            File myFilePath = new File(filePath); 
		            if (!myFilePath.exists()) { 
		                myFilePath.createNewFile(); 
		            } 
		            FileWriter resultFile = new FileWriter(myFilePath); 
		            PrintWriter myFile = new PrintWriter(resultFile); 
		            String strContent = fileContent; 
		            myFile.println(strContent); 
		            resultFile.close(); 
		        } catch (Exception e) { 
		            System.out.println("新建文件操作出错 "); 
		            e.printStackTrace(); 
		        } 
		    }
        
        public  static String makeContent(){  
	       //v.getHomeDirectory(); //这便是读取桌面路径的方法了 
                System.out.println("桌面路径"+System.getProperty("user.home"));
                FileSystemView fsv = FileSystemView.getFileSystemView();
              //  System.out.println("程序路径"+System.getProperty("user.dir"));
	        //修改人：刘磊 2012-8-30 获得机器码
                //String macAddr=MacUtils.getMac();
                String machineCode=CPUSerialUtil.getMachineCode();
                String strpath=fsv.getHomeDirectory().getAbsolutePath() + "\\license.txt";
		StringBuffer fileContent= new StringBuffer();
		fileContent.append("Product.name=eap1.0 ");
		fileContent.append(System.getProperty("line.separator"));//获取系统的换行符
		fileContent.append("Product.version=1.0 ");
		fileContent.append(System.getProperty("line.separator"));
		//fileContent.append("Product.macAddress="+macAddr+"");
                fileContent.append("Product.machineCode="+machineCode+"");
	    try {
		   FileUtils.newFile(strpath, fileContent.toString());
                   //this.getMainJFrame().
                   return "suc";
	   } catch (Exception e) { 
		   e.printStackTrace();
                   return "fail";
	    }
     
        }
        
    
}
